export declare function title(item: any, widgetName: string): any;
