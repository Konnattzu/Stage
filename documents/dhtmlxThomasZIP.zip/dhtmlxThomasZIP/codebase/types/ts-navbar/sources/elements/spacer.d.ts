export declare function spacer(item: any, widgetName: string): any;
