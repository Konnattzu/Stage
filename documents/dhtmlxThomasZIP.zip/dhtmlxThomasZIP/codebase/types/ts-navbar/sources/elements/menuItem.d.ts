export declare function menuItem(item: any, widgetName: string, asMenuItem: boolean): any;
