export declare const grayShades: string[];
export declare const palette: string[][];
