export declare function detectDrag(e: MouseEvent): Promise<any>;
